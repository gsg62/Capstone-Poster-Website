import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-team',
  templateUrl: './about-team.page.html',
  styleUrls: ['./about-team.page.scss'],
})
export class AboutTeamPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
